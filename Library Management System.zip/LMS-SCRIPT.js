"use strict";

const Library = {
    books: [],
    users:[]
};

Library.addBook = function (title, author) {
    const book = {
        id: this.books.length + 1, //! unique book ID
        title: title,
        author: author,
        isIssued: false,
    };
    this.books.push(book);
    console.log(`Book added: ${title} by ${author}`);
    this.displayBooks();
}

Library.displayBooks = function() {
    const bookTable = document.getElementById("bookTable").querySelector('tbody');
    bookTable.innerHTML = '';

    this.books.forEach((book) => {
        const row = document.createElement('tr');
        row.innerHTML = `
        <td>${book.id}</td>
        <td>${book.title}</td>
        <td>${book.author}</td>
        <td>${book.isIssued ? 'Yes' : 'No'}</td>
        <td>
        <button onclick= "Library.issueBook(${book.id})">Issue</button>
        <button onclick= "Library.removeBook(${book.id})">Remove</button>
        </td>
        `;

        bookTable.appendChild(row);
    });
};

Library.removeBook = function(bookId) {
    this.books = this.books.filter((book)=> book.id != bookId);
    console.log(`Book with ID ${bookId} removed.`);
    this.displayBooks();
}

Library.issueBook = function (bookId) {
    const book = this.books.find((b) => b.id === bookId);
    if (book && !book.isIssued) {
        book.isIssued = true;
        console.log(`Book issued: ${book.title}`);
        this.displayBooks();
    } else {
        console.log(`Book with ID ${bookId} is either unavailable or already issued.`);
        
    }
};

document.getElementById("booksForm").addEventListener('submit', (e) => {
    e.preventDefault();
    const title = document.getElementById('bookTitle').value;
    const author = document.getElementById('bookAuthor').value;
    Library.addBook(title, author);
    e.target.reset();
});