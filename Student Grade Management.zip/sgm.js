const grades = [];

document.getElementById('gradesForm').addEventListener('submit', function() {
    event.preventDefault();

    const studentName = document.getElementById('studentName').value;
    const course = document.getElementById('course').value;
    const grade = document.getElementById('grade').value;

    if(!studentName || !course || !grade) {
        alert('Please fill in the fields!');
        return;
    }

    grades.push({studentName, course, grade});
    updateGradesTable();

    document.getElementById('gradesForm').reset();
});

function updateGradesTable() {
    const gradesTableBody = document.getElementById('gradesTable').getElementsByTagName('tbody')[0];
    gradesTableBody.innerHTML = '';

    grades.forEach((entry)=> {
        const row = document.createElement('tr');
        row.innerHTML = `
        <td>${entry.studentName}</td>
        <td>${entry.course}</td>
        <td>${entry.grade}</td>
        `;

        gradesTableBody.appendChild(row);
        });

        displayAverageGrade();
    }

function displayAverageGrade(){
    if(grades.length === 0){
        document.getElementById('averageGrade').innerText = '';
        return;
    }

    let gradeSum = 0;
    grades.forEach((entry)=> {
        switch (entry.grade) {
            case 'A':
                gradeSum += 4;
                break;
            
            case 'B':
                gradeSum += 3;
                break;

            case 'C':
                gradeSum += 2;
                break;

            case 'D':
                gradeSum += 1;
                break;

            case 'F':
                gradeSum += 0;
                break;
        }
    });

    const averageGrade = gradeSum / grades.length;
    const letterGrade = convertToLetterGrade(averageGrade);
}

function convertToLetterGrade(numericGrade) {
    if(numericGrade >= 3.5) return 'A';
    if(numericGrade >= 2.5) return 'B';
    if(numericGrade >= 1.5) return 'C';
    if(numericGrade >= 0.5) return 'D';
    return 'F';
}

