function generateColor() {

    //? Generate first random color in hexadecimal format

    const randomColor1 = "#" + Math.floor(Math.random() * 1677215).toString(16);

    //set the Background color of the box

    document.getElementById("colorBox1").style.backgroundColor = randomColor1;

    //display the color code for the first box

    document.getElementById("colorCode1").textContent = `Color code: ${randomColor1}`;

    
    //?Generate first random color in hexadecimal format

    const randomColor2 = "#" + Math.floor(Math.random() * 1677215).toString(16);

    //set the Background color of the box

    document.getElementById("colorBox2").style.backgroundColor = randomColor2;

    //display the color code for the first box

    document.getElementById("colorCode2").textContent = `Color code: ${randomColor2}`;

    //display the color code below the box

 
}



//! Use onclick in JavaScript

//const button = document.getElementById("myBtn");
// button.onclick = function() {

//     //? Generate first random color in hexadecimal format

//     const randomColor1 = "#" + Math.floor(Math.random() * 1677215).toString(16);

//     //set the Background color of the box

//     document.getElementById("colorBox1").style.backgroundColor = randomColor1;

//     //display the color code for the first box

//     document.getElementById("colorCode1").textContent = `Color code: ${randomColor1}`;

    
//     //?Generate first random color in hexadecimal format

//     const randomColor2 = "#" + Math.floor(Math.random() * 1677215).toString(16);

//     //set the Background color of the box

//     document.getElementById("colorBox2").style.backgroundColor = randomColor2;

//     //display the color code for the first box

//     document.getElementById("colorCode2").textContent = `Color code: ${randomColor2}`;

//     //display the color code below the box

 
// }



//! Using addEventListener Instead of onclick

// const button = document.getElementById("myBtn");

// button.addEventListener("click", function() {

//     //? Generate first random color in hexadecimal format

//     const randomColor1 = "#" + Math.floor(Math.random() * 1677215).toString(16);

//     //set the Background color of the box

//     document.getElementById("colorBox1").style.backgroundColor = randomColor1;

//     //display the color code for the first box

//     document.getElementById("colorCode1").textContent = `Color code: ${randomColor1}`;

    
//     //?Generate first random color in hexadecimal format

//     const randomColor2 = "#" + Math.floor(Math.random() * 1677215).toString(16);

//     //set the Background color of the box

//     document.getElementById("colorBox2").style.backgroundColor = randomColor2;

//     //display the color code for the first box

//     document.getElementById("colorCode2").textContent = `Color code: ${randomColor2}`;

//     //display the color code below the box

 
// })