'use strict';

class Product {
    constructor(name, price, category) {
        this.name = name;
        this.price = price;
        this.category = category;
        this.id = Symbol(name); 
    }
}

class Inventory {
    constructor() {
        this.products = [];
    }

    addProduct(product) {
        this.products.push(product);
        this.renderInventory();
    }

    removeProduct(productId) {
        this.products = this.products.filter(product => product.id !== productId );
        this.renderInventory();
    } 

    renderInventory () {
        const inventoryList = document.getElementById('inventoryList');
        inventoryList.innerHTML = '';
        this.products.forEach((product) => {
            const li = document.createElement('li');
            li.innerHTML = `
            <div class= "product-details">
            <strong>${product.name}</strong> -- $${product.price} (${product.category})
            </div>
            <button class= "remove-btn" data-id = "${product.id.toString()}">Remove</button>
            `;

            li.querySelector('.remove-btn').addEventListener('click',() => {
                this.removeProduct(product.id);
            });
            inventoryList.appendChild(li);
        });
    }
}

const inventory = new Inventory();

document.getElementById('productForm').addEventListener('submit', (e) => {
    e.preventDefault();

    const name = document.getElementById('productName').value;
    const price = document.getElementById('productPrice').value;
    const category = document.getElementById('productCategory').value;

    if (name && !isNaN(price) && category) {
        const product = new Product (name, price, category);
        inventory.addProduct(product);

        document.getElementById('productForm').reset();
    } else {
        alert ('Please fill in all fields correctly!');
    }
});

