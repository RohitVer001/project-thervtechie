//Target the DOM Elements
const taskInput = document.getElementById("taskInput");
const addTaskBtn = document.getElementById("addTaskBtn");
const taskList = document.getElementById("taskList");

//Add Event Listener to the Button

addTaskBtn.addEventListener("click", function () {
    const taskText = taskInput.value;


    //Validate input (not empty)

    //?if(task.trim()==="") check the empty input and if empty then pop-up

    if (taskText.trim() === "") {
        alert("Please enter a task!");
        return;
    }

   
    //!Create a new list item
    
    const listItem = document.createElement("li");
    const crossImg = document.createElement("img");  // Create an image element
    crossImg.src = "cross.png";  // Specify the image source (replace with your image path)
    crossImg.alt = "Delete";  // Add an alt text for accessibility
    crossImg.classList.add("delete-img"); // Optional: for styling the image



    // Add the task text to the list item
    listItem.textContent = taskText;
    listItem.appendChild(crossImg);
    
    //! Add the new task to the list

    taskList.appendChild(listItem);
    
    //! Clear the input field
    taskInput.value = "";

    //! Add event listener to delete the task

    crossImg.addEventListener("click", function() {
        taskList.removeChild(listItem);
    })
})

